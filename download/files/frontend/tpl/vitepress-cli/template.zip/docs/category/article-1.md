---
title: Article 1
---

# Article 1